export default [
    {
        id: 1,
        name: 'Rukshana',
        apt: 'E-51',
        zipCode: '',
        state: 'Punjab',
        city: 'Mohali',
        country: 'India',
        addressLine1: '',
        addressLine2: 'Phase 8',
        phone: '',
        altPhone: '',
        emailAddress: '',
        isDefault: true
    },
    {
        id: 2,
        name: 'Sukhpal Singh',
        apt: '#12',
        zipCode: '',
        state: 'Chandigarh',
        city: 'Chandigarh',
        country: 'India',
        addressLine1: 'Near TY Hospital',
        addressLine2: '',
        phone: '',
        altPhone: '',
        emailAddress: '',
        isDefault: false
    }
]