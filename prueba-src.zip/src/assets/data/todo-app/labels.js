/**
 * Todo App Data
 * Used To Describe Task Tyoe
 */
export default [
    {
        name: 'Frontend',
        value: 1
    },
    {
        name: 'Backend',
        value: 2
    },
    {
        name: 'Api',
        value: 3
    },
    {
        name: 'Issue',
        value: 4
    }
];
