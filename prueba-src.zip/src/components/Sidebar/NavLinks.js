// sidebar nav links
export default {
      category1: [
            {
                  "menu_title": "sidebar.dashboard",
                  "menu_icon": "ti-dashboard",
                  "path": "/app/dashboard",
                  "child_routes": null
            },
            {
                  "menu_title": "Clientes",
                  "menu_icon": "ti-heart",
                  "path": "/app/widgets",
                  "child_routes": null
            },
            {
                  "menu_title": "Usuarios",
                  "menu_icon": "ti-user",
                  "path": "/app/widgets",
                  "child_routes": null
            },
            {
                  "menu_title": "Tags Audiovisuales",
                  "menu_icon": "ti-tag",
                  "path": "/app/widgets",
                  "child_routes": null
            },
            
            
      ]
}
